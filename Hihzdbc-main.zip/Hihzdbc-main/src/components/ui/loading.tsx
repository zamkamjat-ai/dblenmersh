import { ImageIcon } from "lucide-react"

type LoadingStateProps = {
  message: string
  description?: string
  className?: string
}

export function LoadingState({ message, description, className }: LoadingStateProps) {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 rounded-3xl border border-border bg-card/80 p-8 text-center ${className ?? ""}`}>
      <span className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
        <ImageIcon className="size-6" />
      </span>
      <div className="space-y-1">
        <p className="text-base font-semibold text-foreground">{message}</p>
        {description ? <p className="text-sm text-muted-foreground">{description}</p> : null}
      </div>
    </div>
  )
}
