import type { VercelRequest, VercelResponse } from '@vercel/node';

/**
 * Backend-side image proxy and upload handler
 * Keeps ImgBB API key secure (never exposed to client)
 */
export async function handleImageUpload(req: VercelRequest, res: VercelResponse) {
  if (req.method === 'POST') {
    const contentTypeHeader = req.headers['content-type'];
    const contentType = Array.isArray(contentTypeHeader) ? contentTypeHeader[0] : contentTypeHeader;
    const contentLengthHeader = req.headers['content-length'];
    const contentLength = Array.isArray(contentLengthHeader) ? contentLengthHeader[0] : contentLengthHeader;

    if (!contentType || !contentType.includes('multipart/form-data')) {
      return res.status(400).json({
        success: false,
        error: 'Content-Type must be multipart/form-data'
      });
    }

    const apiKey = process.env.IMGBB_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        success: false,
        error: 'Image service not configured'
      });
    }

    try {
      const headers: Record<string, string> = { 'content-type': contentType };
      if (contentLength) {
        headers['content-length'] = contentLength;
      }

      const requestBuffer = await readRequestBody(req);
      const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
        method: 'POST',
        headers,
        body: new Uint8Array(requestBuffer),
      });

      const payload = await response.json();
      if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message ?? 'Upload failed');
      }

      const imageUrl = payload.data?.display_url ?? payload.data?.url;
      if (!imageUrl) {
        throw new Error('Upload succeeded without an image URL');
      }

      return res.status(200).json({
        success: true,
        data: { url: imageUrl }
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Upload failed';
      return res.status(500).json({
        success: false,
        error: message
      });
    }
  }

  return res.status(405).json({
    success: false,
    error: `Method ${req.method} not allowed`
  });
}

async function readRequestBody(req: VercelRequest): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}
