import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dbrutalRouter from "./dbrutals";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dbrutalRouter);

export default router;
